# Instruction: images flottantes

Comprendre le fonctionnement du float

## HTML
- Utilisation des balises sémantiques article pour les chats
- Lien Pixabay : https://pixabay.com

## CSS

- Largeur limitée: maximum à 960px (utilisation d'une classe .container)
